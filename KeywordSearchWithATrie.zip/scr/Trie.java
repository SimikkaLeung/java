
/**
 * @author simik
 *
 */
public class Trie {
	
	private Node root;
	
	public Trie() {
		root = new Node('*');
	}
	
	// insert
	
	public void insert ( String word, String paragraph_num ) {
		word = word.toLowerCase();		// Convert the word into lower cases
		Node current = root;
		
		for (int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			if ( c >= 'a' &&  c <= 'z') {
				if (current.children[c - 'a'] == null) {
					current.children[c - 'a'] = new Node(c);
				}
			current = current.children[c - 'a'];		// Move on to the next node
			}
			
		}
		
		current.isWord = true;
		String[] occurence = current.which_paragraphs.split(",", 0);
		if (occurence[occurence.length - 1].compareTo(paragraph_num) != 0 ) {
			current.which_paragraphs = current.which_paragraphs.concat(paragraph_num);
			current.which_paragraphs = current.which_paragraphs.concat(",");
		}

		
		
		
		
	}
	// search
	
	public String search(String word) {
		Node node = getLastNode(word);
		if (node != null && node.isWord) {			// true only if the node is not null and it end of a word.		
			return node.which_paragraphs;
		} else {
			return "-1000";
		}
		

	}
	
	public Node getLastNode (String word) {
		word = word.toLowerCase();
		
		Node current = root;
		
		for (int i = 0; i < word.length(); i++ ) {
			char c = word.charAt(i);
			if ( c >= 'a' &&  c <= 'z') {
				if (current.children[c - 'a'] == null) {
					return null;
				} else {
					current = current.children[c - 'a'];		// Move on to the next node
				}
			}
			
		}
		
		return current;
	}
	
	
	
	class Node {
		
		public char c;
		public boolean isWord;
		public Node[] children;
		public String which_paragraphs;
		
		public Node(char c) {
			
			this.c = c;
			isWord = false;
			children = new Node[26]; // 26 alphabets
			which_paragraphs = "";
			
		}

	}

}
