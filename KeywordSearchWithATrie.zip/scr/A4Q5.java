import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class A4Q5 {
	
	public static String [] readText(String fileLocation) throws FileNotFoundException  {

		
		File textFile = new File(fileLocation);
		

		Scanner scan = new Scanner(textFile);
		Scanner lineCounter = new Scanner(textFile);
		
		// To count the number of paragraphs in the text file.
		
		int lineCount = 0;
		
		while (lineCounter.hasNextLine()) {
			lineCount++;
			lineCounter.nextLine();
		}
		
		String[] stringArr = new String[lineCount];
		
		for (int i = 0; i < lineCount; i++) {
			stringArr[i] = scan.nextLine();
		}
		
		// Close both scanner objects.
		scan.close();			
		lineCounter.close();
		
		return stringArr;
	}
	
	public static Trie buildTrie (String[] paragraph, String[] stopword, Trie trie) {
		Trie stopword_trie = new Trie();
		for (int m = 0; m < stopword.length; m++) {
			String[] stopwords = stopword[m].split(" ", 0);	
			for (int n = 0; n < stopwords.length; n++ ) {
				stopword_trie.insert(stopwords[n], String.valueOf(n));
			}
			
		}

		for (int i = 0; i < paragraph.length; i++) {
			

			String[] words = paragraph[i].split(" ", 0);
				for (int j = 0; j < words.length; j++ ) {
					
					if (stopword_trie.search(words[j]).compareTo("-1000") == 0 ) {		// If the word in the paragraph array is not in the stopword_trie
						trie.insert(words[j], String.valueOf(i) );
					}
				}
			}
	

		
		return trie;
	
	}
	
	
	
	public static String[] parseExpression (String keywordString) {
		String processedKeywordString = "";
		
		for (int i = 0; i < keywordString.length(); i++) {
			if (keywordString.charAt(i) == '(') {
				processedKeywordString = processedKeywordString + keywordString.charAt(i);
				processedKeywordString = processedKeywordString + " ";
				
			} else if (keywordString.charAt(i) == ')') {
				processedKeywordString = processedKeywordString + " ";
				processedKeywordString = processedKeywordString + keywordString.charAt(i);
				
			} else {
				processedKeywordString = processedKeywordString + keywordString.charAt(i);
			}
		}
		
		String[] expressionComponent = processedKeywordString.split(" ", 0);
		return expressionComponent;
		
	}
	
	public static String keywordSearch (Scanner keyboard, Trie trie) {
		String keywordString;
		System.out.print("Enter the keyword(s) that you want to search for. ");
		System.out.println("If you want to search for two keywords, You must have \" and \" / \" or \" between two keywords.");
		System.out.println("If you want to search for more than two keywords, you need additional \"(\" and \")\" for each pair of keywords");
		System.out.print("Input: ");
		keywordString = keyboard.nextLine();
		
		String[] expressionComponent = parseExpression(keywordString);

		if (expressionComponent.length == 1) {
			
			return trie.search(expressionComponent[0]);
		}
		//	Continue if we have more than one keyword to search
		
		boolean toContinue = true;
		boolean isValid = true;
		int andIndex = -1;
		int orIndex = -1;
		int num_openParenthesis = 0;
		int num_closingParenthesis = 0;
		String openParenthesisIndices = "-1,";	//	Assume the invisible open parenthesis is outside the keywordString.
		String closingParenthesisIndices = "";	// //	Assume the invisible closing parenthesis is outside the keywordString.
		for (int i = 0; i < expressionComponent.length; i++) {
			if ( expressionComponent[i].compareTo("(") == 0 ) {
				num_openParenthesis++;
				openParenthesisIndices = openParenthesisIndices.concat(String.valueOf(i));
				openParenthesisIndices = openParenthesisIndices.concat(",");
			} else if ( expressionComponent[i].compareTo(")") == 0 ) {
				num_closingParenthesis++;
				closingParenthesisIndices = closingParenthesisIndices.concat(String.valueOf(i));
				closingParenthesisIndices = closingParenthesisIndices.concat(",");
			}
		}
		closingParenthesisIndices = closingParenthesisIndices.concat(String.valueOf(expressionComponent.length));	// //	Assume the invisible closing parenthesis is outside the keywordString.
		closingParenthesisIndices = closingParenthesisIndices.concat(",");
		
		
		
		int parenthesisPairsLeft = -1;
		String[] openParenthesis;
		String[] closingParenthesis;
		if (num_openParenthesis != num_closingParenthesis) {
			isValid = false;
			return ("Invalid Input");
		} 
		openParenthesis = openParenthesisIndices.split(",", 0 );
		closingParenthesis = closingParenthesisIndices.split(",", 0 );
		parenthesisPairsLeft = num_openParenthesis + 1;		// Including the invisible brackets for the entire expression.


		int indexOfOpenParenthesis;
		int indexOfClosingParenthesis;
		int pointer = Integer.parseInt(openParenthesis[num_openParenthesis]) + 2;
		int backwardCounter = pointer-1;
		int forwardCounter = pointer+1;
		

		

		while (parenthesisPairsLeft > 0 && isValid) {
			indexOfOpenParenthesis = Integer.parseInt(openParenthesis[parenthesisPairsLeft-1]);
			indexOfClosingParenthesis = Integer.parseInt(closingParenthesis[closingParenthesis.length-parenthesisPairsLeft]);


			if (expressionComponent[pointer].compareTo("and") == 0 || expressionComponent[pointer].compareTo("or") == 0) {
				boolean PreceedingKeywordFound = false;

				
				while (!PreceedingKeywordFound && backwardCounter > indexOfOpenParenthesis) {
					if (expressionComponent[backwardCounter].compareTo("(") == 0 || expressionComponent[backwardCounter].compareTo(")") == 0 || expressionComponent[backwardCounter].compareTo("") == 0) {
						backwardCounter--;
					} else {
						PreceedingKeywordFound = true;
					}
				}
				
				if (backwardCounter <= indexOfOpenParenthesis) {
					isValid = false;
				}
				
				boolean SucceedingKeywordFound = false;
				
				while (!SucceedingKeywordFound && forwardCounter < indexOfClosingParenthesis) {
										
					if (expressionComponent[forwardCounter].compareTo("(") == 0 || expressionComponent[forwardCounter].compareTo(")") == 0 || expressionComponent[forwardCounter].compareTo("") == 0) {
						forwardCounter++;
					} else {
						SucceedingKeywordFound = true;
					}
				}
				
				
				if (PreceedingKeywordFound && SucceedingKeywordFound && expressionComponent[pointer].compareTo("and") == 0 ) {
					expressionComponent[pointer] = andOperation(expressionComponent[backwardCounter], expressionComponent[forwardCounter], trie);
					expressionComponent[forwardCounter] = "";	// So that the array element will be ignored in future loops.
					expressionComponent[backwardCounter] = "";
				} else if (PreceedingKeywordFound && SucceedingKeywordFound && expressionComponent[pointer].compareTo("or") == 0 ) {
					expressionComponent[pointer] = orOperation(expressionComponent[backwardCounter], expressionComponent[forwardCounter], trie);
					expressionComponent[forwardCounter] = "";	// So that the array element will be ignored in future loops.
					expressionComponent[backwardCounter] = "";
				}
			
			}		// End of the big-if statement.
			
			

			if (forwardCounter < indexOfClosingParenthesis - 1) {		// if there is still any component to be evaluated within the current parenthesis.
				
				pointer++;
				backwardCounter = pointer-1;
				forwardCounter = pointer+1;
			} else if (parenthesisPairsLeft > 1) {
				parenthesisPairsLeft--;
				pointer = Integer.parseInt(openParenthesis[parenthesisPairsLeft-1]) + 2;		
				backwardCounter = pointer-1;
				forwardCounter = pointer+1;
			} else {
				return expressionComponent[pointer];
			}
			
		}
		
	return expressionComponent[pointer];
		
	}
	
	
	
		
	
	
	
	public static String andOperation (String firstKeyword, String secondKeyword, Trie trie) {
		// Check if the input are actual keywords or paragraph numbers.
		
		String[] first_paragraphs;
		String[] second_paragraphs;
		
		if ( firstKeyword.charAt(firstKeyword.length()-1) == ',' ) {
			first_paragraphs = firstKeyword.split(",",0);
		} else {
			first_paragraphs = trie.search(firstKeyword).split(",",0);
		}
		
		if ( secondKeyword.charAt(secondKeyword.length()-1) == ',' ) {
			second_paragraphs = secondKeyword.split(",", 0);
		} else {
			second_paragraphs = trie.search(secondKeyword).split(",",0);
		}
		
		String shared_paragraphs = "";
		
		if (first_paragraphs[0] == "-1000" || second_paragraphs[0] == "-1000" ) {
			return ("-1000");
		} else {
			for (int k = 0; k < first_paragraphs.length; k++) {
				for (int m = 0; m < second_paragraphs.length; m++) {
				
					if (first_paragraphs[k].compareTo(second_paragraphs[m]) == 0) {
						shared_paragraphs = shared_paragraphs.concat(first_paragraphs[k]);
						shared_paragraphs = shared_paragraphs.concat(",");
					}
				}				
			}
			
		}	
		return (shared_paragraphs);
	}
	

	public static String orOperation (String firstKeyword, String secondKeyword, Trie trie) {
		// Check if the input are actual keywords or paragraph numbers.
		
		String[] first_paragraphs;
		String[] second_paragraphs;
		
		if ( firstKeyword.charAt(firstKeyword.length()-1) == ',' ) {
			first_paragraphs = firstKeyword.split(",",0);

		} else {
			first_paragraphs = trie.search(firstKeyword).split(",",0);
		}
		
		if ( secondKeyword.charAt(secondKeyword.length()-1) == ',' ) {
			second_paragraphs = secondKeyword.split(",", 0);
		} else {
			second_paragraphs = trie.search(secondKeyword).split(",",0);
		}
		
		String all_paragraphs = "";

		int firstCounter = 0;
		int secondCounter = 0;
		
	
		
		if (first_paragraphs[0] == "-1000" || second_paragraphs[0] == "-1000" ) {
			return ("-1000");
		} else {
			
			while ( firstCounter < first_paragraphs.length || secondCounter < second_paragraphs.length ) {
				if (firstCounter >= first_paragraphs.length) {
					all_paragraphs = all_paragraphs.concat(second_paragraphs[secondCounter]);
					all_paragraphs = all_paragraphs.concat(",");
					secondCounter++;
				} else if (secondCounter >= second_paragraphs.length) {
					all_paragraphs = all_paragraphs.concat(first_paragraphs[firstCounter]);
					all_paragraphs = all_paragraphs.concat(",");
					firstCounter++;
				} else if ( Integer.parseInt(first_paragraphs[firstCounter]) < Integer.parseInt(second_paragraphs[secondCounter]) ) {
					all_paragraphs = all_paragraphs.concat(first_paragraphs[firstCounter]);
					all_paragraphs = all_paragraphs.concat(",");
					firstCounter++;
				} else if ( Integer.parseInt(first_paragraphs[firstCounter]) > Integer.parseInt(second_paragraphs[secondCounter]) ) {
					all_paragraphs = all_paragraphs.concat(second_paragraphs[secondCounter]);
					all_paragraphs = all_paragraphs.concat(",");
					secondCounter++;
				} else if ( Integer.parseInt(first_paragraphs[firstCounter]) == Integer.parseInt(second_paragraphs[secondCounter]) ) {
					all_paragraphs = all_paragraphs.concat(first_paragraphs[firstCounter]);
					all_paragraphs = all_paragraphs.concat(",");
					firstCounter++;
					secondCounter++;
				}
				
			}
			
		
		}	
		return (all_paragraphs);
	}
	
	public static void printResults (String results, String[] paragraph) {
		String[] result_paragraph;
		if (results == "-1000") {
			System.out.println("Not found.");
		} else {
			result_paragraph = results.split(",", 0);
			System.out.print("The paragraph(s) that you are looking for is/are: ");
			for (int i = 0; i < result_paragraph.length ; i++) {
				System.out.print(Integer.parseInt(result_paragraph[i])+1);			// the order starts from 1, not 0.
				if ( i != result_paragraph.length - 1) {
					System.out.print(", ");
				}
			}
			System.out.println();
			System.out.println();
			
			for (int j = 0; j < result_paragraph.length ; j++) {
				System.out.print( ( Integer.parseInt(result_paragraph[j])+1 ) + "\t");			// the order starts from 1, not 0.
				System.out.print(paragraph[Integer.parseInt(result_paragraph[j])]);
				System.out.println();
				System.out.println();
			}
		}
		
	}
	
	public static void main (String[] args) throws FileNotFoundException {
		
		Scanner keyboard = new Scanner(System.in);
		
		Trie trie = new Trie();
		
		// Store paragraphs of an article
		String textFile = ".\\src\\paragraphs.txt";
		
		String[] paragraph = readText(textFile);
		// Store paragraphs of an article
		String listOfStopWords = ".\\src\\List of Stop Words.txt";
		
		String[] stopword = readText(listOfStopWords);
		
		
		trie = buildTrie(paragraph, stopword, trie);

		String answer = keywordSearch(keyboard,trie);
		printResults(answer, paragraph);
		
		keyboard.close();

	}
	
	

}
